const Promotion = () => {
  return <h1>광고</h1>;
};

export default Promotion;
