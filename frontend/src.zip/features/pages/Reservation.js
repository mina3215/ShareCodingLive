const Reservation = () => {
  return <h1>예약</h1>;
};
export default Reservation;
